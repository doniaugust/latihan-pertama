@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo Memasang sertifikat SSL Windows dan certifi...
py -3 -m pip install --upgrade truststore certifi
if errorlevel 1 (
 echo Gagal memasang paket. Coba jalankan dengan Python aktif atau hubungi IT untuk proxy.
 pause
 exit /b 1
)
echo.
echo Integrasi 9 kota, memakai cuaca_perjam.csv lama bila tersedia...
if exist "cuaca_perjam.csv" (
 py -3 ambil_dan_gabung_cuaca.py --beban "beban_30menit.csv" --cuaca-lama "cuaca_perjam.csv"
) else (
 py -3 ambil_dan_gabung_cuaca.py --beban "beban_30menit.csv"
)
echo.
pause
