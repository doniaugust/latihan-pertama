import csv, json, time, urllib.parse, urllib.request, pathlib, argparse, datetime as dt, collections, ssl
try:
 import certifi
except ImportError:
 raise SystemExit("Paket certifi belum terpasang. Jalankan: python -m pip install --upgrade certifi")
# Windows: use trusted Windows certificate store via truststore, which also handles
# office proxy certificates when installed by the organization.
try:
 import truststore
 truststore.inject_into_ssl()
 SSL_CONTEXT = ssl.create_default_context()
 print('SSL: Windows/system trust store (truststore)',flush=True)
except ImportError:
 SSL_CONTEXT = ssl.create_default_context(cafile=certifi.where())
 print('SSL: certifi CA bundle (install truststore if certificate fails)',flush=True)
ROOT=pathlib.Path(__file__).resolve().parent
CITIES=[('SBU','Banda Aceh',5.55,95.32),('SBU','Medan',3.59,98.67),('SBU','Pematangsiantar',2.96,99.06),('SBT','Pekanbaru',0.51,101.45),('SBT','Padang',-0.95,100.35),('SBT','Jambi',-1.61,103.61),('SBS','Palembang',-2.99,104.76),('SBS','Bandar Lampung',-5.43,105.26),('SBS','Bengkulu',-3.79,102.26),('SBS','Pangkalpinang',-2.13,106.11)]
VARS=['temperature_2m','relative_humidity_2m','apparent_temperature','precipitation','cloud_cover']
def months(a,b):
 d=dt.date(a.year,a.month,1)
 while d<=b:
  last=(dt.date(d.year+1,1,1) if d.month==12 else dt.date(d.year,d.month+1,1))-dt.timedelta(days=1)
  yield max(d,a),min(last,b)
  d=last+dt.timedelta(days=1)
def fetch(city,start,end,cache):
 area,name,lat,lon=city
 p=cache/(name.replace(' ','_')+'_'+str(start)+'_'+str(end)+'.json')
 if p.exists():
  cached=json.loads(p.read_text(encoding='utf-8'))
  if 'hourly' in cached and not cached.get('error'): return cached
 params=dict(latitude=lat,longitude=lon,start_date=str(start),end_date=str(end),hourly=','.join(VARS),timezone='Asia/Jakarta',models='era5')
 url='https://archive-api.open-meteo.com/v1/archive?'+urllib.parse.urlencode(params)
 for attempt in range(4):
  try:
   with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'LoadForecastResearch/1.0'}),timeout=90,context=SSL_CONTEXT) as r: obj=json.load(r)
   if obj.get('error') or 'hourly' not in obj: raise ValueError(str(obj))
   p.write_text(json.dumps(obj),encoding='utf-8'); return obj
  except Exception as e:
   if attempt==3: raise RuntimeError(f'{name} {start}..{end}: {e}. Jika SSL gagal, periksa jam Windows dan sertifikat proxy kantor; jalankan pip install --upgrade truststore certifi')
   time.sleep(2**attempt*3)
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--beban',required=True,help='Path beban_30menit.csv');ap.add_argument('--mulai',default='2024-01-01');ap.add_argument('--akhir',default='2026-11-09');ap.add_argument('--cuaca-lama',default='',help='Opsional: cuaca_perjam.csv sebelumnya untuk menghindari unduhan 8 kota');args=ap.parse_args()
 start=dt.date.fromisoformat(args.mulai); end=dt.date.fromisoformat(args.akhir)
 cache=ROOT/'cache_cuaca';cache.mkdir(exist_ok=True);out=ROOT/'hasil';out.mkdir(exist_ok=True)
 weather={};errors=[]
 if args.cuaca_lama:
  with open(args.cuaca_lama,encoding='utf-8-sig',newline='') as f:
   for row in csv.DictReader(f):
    weather[(row['kota'],row['tanggal_jam_wib'])]=[row.get(v,'') for v in VARS]
  print('Cuaca lama dimuat:',len(weather),'baris',flush=True)
 for city in CITIES:
  area,name,lat,lon=city
  for a,b in months(start,end):
   # If every hour for the month is already in old data, skip downloading.
   hours=int(((dt.datetime.combine(b,dt.time(23))-dt.datetime.combine(a,dt.time(0))).total_seconds()/3600)+1)
   if sum((name,f'{(dt.datetime.combine(a,dt.time())+dt.timedelta(hours=i)).isoformat(timespec="minutes")}') in weather for i in range(hours))==hours:
    print('CACHE',name,a,b,flush=True);continue
   try:
    obj=fetch(city,a,b,cache);h=obj['hourly'];
    for i,t in enumerate(h['time']):weather[(name,t)]=[h.get(v,[None]*len(h['time']))[i] for v in VARS]
    print('OK',name,a,b,flush=True)
   except Exception as e:errors.append(str(e));print('ERROR',e,flush=True)
 with (out/'cuaca_perjam.csv').open('w',newline='',encoding='utf-8-sig') as f:
  w=csv.writer(f);w.writerow(['kota','tanggal_jam_wib']+VARS)
  for (name,t),vals in sorted(weather.items()):w.writerow([name,t]+vals)
 # Preserve logsheet date and 24:00 semantics: 24:00 -> next calendar day 00:00
 # Weather at 00:30 is mapped to the 00:00 weather record; no interpolation is claimed.
 mapping={'ACEH':'Banda Aceh','SUMUT':'Medan','SUMBAR':'Padang','RIAU':'Pekanbaru','JAMBI':'Jambi','SUMSEL':'Palembang','LAMPUNG':'Bandar Lampung','BENGKULU':'Bengkulu','BANGKA':'Pangkalpinang'}
 counts=collections.Counter()
 with open(args.beban,encoding='utf-8-sig',newline='') as fi,(out/'beban_cuaca_subsistem.csv').open('w',encoding='utf-8-sig',newline='') as fo:
  reader=csv.DictReader(fi);cols=['tanggal','jam','periode','kelompok','subsistem','beban_plus_padam_mw','padam_mw','status_kualitas_data','kota_cuaca','jam_cuaca_wib']+VARS+['status_pencocokan'];writer=csv.DictWriter(fo,fieldnames=cols);writer.writeheader()
  for row in reader:
   sub=row['subsistem'].strip().upper();name=mapping.get(sub)
   if sub not in mapping:continue
   d=dt.date.fromisoformat(row['tanggal']);hh,mm=map(int,row['jam'].split(':'))
   if hh==24:d+=dt.timedelta(days=1);hh=0
   t=f'{d.isoformat()}T{hh:02d}:00';vals=weather.get((name,t)) if name else None
   status='OK' if vals else 'CUACA_TIDAK_TERSEDIA'
   rec={k:row.get(k,'') for k in cols};rec.update(kota_cuaca=name or '',jam_cuaca_wib=t,status_pencocokan=status)
   if vals:
    for k,v in zip(VARS,vals):rec[k]=v
   writer.writerow(rec);counts[status]+=1
 with (out/'audit_cuaca.txt').open('w',encoding='utf-8') as f:
  f.write('PERIODE '+str(start)+' sampai '+str(end)+'\n');f.write('Mapping cuaca: interval 30 menit menggunakan data cuaca jam sebelumnya; 24:00 = 00:00 hari berikutnya.\n');f.write('Bangka tidak dipetakan: tambahkan Pangkalpinang setelah menentukan koordinat.\n');f.write('Cakupan: hanya subsistem/provinsi terpetakan; agregat UP2B dan Sumatera tidak dihitung ulang.\n')
  for k,v in counts.items():f.write(f'{k}: {v}\n')
  for e in errors:f.write('ERROR: '+e+'\n')
 print('SELESAI',dict(counts),'Hasil:',out,flush=True)
if __name__=='__main__':main()
